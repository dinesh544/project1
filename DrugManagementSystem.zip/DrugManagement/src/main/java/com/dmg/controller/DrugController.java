package com.dmg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dmg.model.Drug;
import com.dmg.service.DrugService;

@RestController
public class DrugController {
	
	@Autowired
	private DrugService ds;
	
	@GetMapping("/hello")
	public String hello() {
		return "Welcome";
	}

	@PostMapping("/addDrug")
	public ResponseEntity<Drug> addDrug(@RequestBody Drug drug) {
		return ResponseEntity.ok(ds.addDrug(drug));
		
	}
	
	@PostMapping("/removeDrug/{id}")
	public void removeDrug(@PathVariable Long id) {
		ds.deleteDrug(id);
	}
	
	@PutMapping("/updateDrug/{id}")
	public Drug updateDrug(@PathVariable Long id,@RequestBody Drug drug){
		Drug d = ds.searchDrugById(id);
		d.setDescription(drug.getDescription());
		d.setId(drug.getId());
		d.setName(drug.getName());
		d.setPrice(drug.getPrice());
		d.setQuantity(drug.getQuantity());
		return ds.addDrug(d);
	    }
	
	@GetMapping("/getAllDrugs")
	public List<Drug> getAllDrugs(){
		System.out.println("hello");
		return ds.getAllDrugs();
	}
		
		
		
		
	

}
