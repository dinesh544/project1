package com.dmg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dmg.model.Drug;

public interface DrugRepository extends JpaRepository<Drug,Long>  {

}
