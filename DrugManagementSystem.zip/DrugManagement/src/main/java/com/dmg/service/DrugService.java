package com.dmg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import com.dmg.dao.DrugRepository;
import com.dmg.model.Drug;

@Service
public class DrugService {
	
	@Autowired
	DrugRepository dr;
	
	public Drug addDrug(Drug drug) {
		Drug save = dr.save(drug);
		if(save == null) {
			throw new RuntimeException("Drug not saved");
		}
		return  save;
		
	}
	
	public void deleteDrug(Long id) {
		 dr.deleteById(id);
	}
	
	public Drug searchDrugById(Long id) {
		return dr.findById(id).orElseThrow(()->new RuntimeException("Drug not found"));
	}
	
	public List<Drug> getAllDrugs(){
		return dr.findAll();
	}
	
	
	
 
	

}
