package com.smg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.smg.model.Supplier;
import com.smg.service.SupplierService;

@RestController
public class SupplierController {
	
	@Autowired
	SupplierService supplierService;
	
	@GetMapping("/hello")
	public String hello() {
		return "Welcome";
	}
	
	@PostMapping("/createSupplier")
	public Supplier createSupplier(@RequestBody Supplier supplier){
		return supplierService.createSupplier(supplier) ;
		
	}
	
	@GetMapping("/getAllSuppliers")
	public List<Supplier> getAllSuppliers() {
		return supplierService.getAllSuppliers();
		
	}
	
//	@GetMapping("/getSupplierById/{id}")
//	public ResponseEntity<Supplier> getSupplierById(@PathVariable Long id){
//		Supplier supplier = supplierService.getSupplierById(id) ;
//		return ResponseEntity.ok(supplier);
//		
//	}
//	
	@PutMapping("/updateSupplier/{id}")
	public Supplier updateSupplier(@PathVariable Long id, @RequestBody Supplier supplier) {
		return supplierService.updateSupplier(id, supplier);
	}
	
	@DeleteMapping("/deleteSupplier/{id}")
	public void deleteSupplier(@PathVariable Long id){
		supplierService.deleteSupplier(id);
		
		
	}
	
	
	
	
	
	

}
