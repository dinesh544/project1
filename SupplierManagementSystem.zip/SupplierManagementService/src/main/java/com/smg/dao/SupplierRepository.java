package com.smg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smg.model.Supplier;


public interface SupplierRepository extends JpaRepository<Supplier,Long> {

}
