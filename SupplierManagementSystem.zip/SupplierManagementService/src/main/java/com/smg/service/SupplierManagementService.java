package com.smg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.smg.dao.SupplierRepository;
import com.smg.model.Supplier;

@Service
public class SupplierManagementService implements SupplierService {

	@Autowired
	SupplierRepository supplierRepository;
	
	@Override
	public Supplier createSupplier(@RequestBody Supplier supplier) {
		return supplierRepository.save(supplier)  ;
	}

	@Override
	public List<Supplier> getAllSuppliers() {
		// TODO Auto-generated method stub
		return supplierRepository.findAll();
	}

	//@Override
//	public Supplier getSupplierById(Long id) {
//		// TODO Auto-generated method stub
//		return supplierRepository.findById(id).orElseThrow(()-> new RuntimeException("Supplier not found with id"+id));
//	}

	@Override
	public Supplier updateSupplier(Long id, Supplier supplierDetails) {
		 Optional<Supplier> supplier = supplierRepository.findById(id);
		 Supplier supplier2 = supplier.get();
		if(supplier.isEmpty()) {
			throw new RuntimeException("No Drug found"+id);
		}
		
		supplier2.setName(supplierDetails.getName());
		supplier2.setContactInfo(supplierDetails.getContactInfo());
		supplier2.setAddress(supplierDetails.getAddress());
		supplier2.setEmail(supplierDetails.getEmail());
		
		return supplierRepository.save(supplier2) ;
	}

	@Override
	public void deleteSupplier(Long id) {
		supplierRepository.findById(id);
		
	}

}
