package com.smg.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.smg.model.Supplier;

@Service
public interface SupplierService {
	Supplier createSupplier(Supplier supplier);
	List<Supplier> getAllSuppliers();
	//Supplier getSupplierById(Long id);
	Supplier updateSupplier(Long id,Supplier supplierDetails);
	void deleteSupplier(Long id);
	
	
	

}
