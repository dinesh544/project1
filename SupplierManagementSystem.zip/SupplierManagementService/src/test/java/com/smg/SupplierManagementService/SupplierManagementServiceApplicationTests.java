package com.smg.SupplierManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplierManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
